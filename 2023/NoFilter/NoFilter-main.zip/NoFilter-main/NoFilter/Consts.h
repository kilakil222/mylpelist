#pragma once
#include "WfpClient.h"

extern const wchar_t* g_PolicyName;
extern GUID g_ProviderGuid;
extern const wchar_t* g_LocalAddress;
extern const wchar_t* g_RemoteAddress;
extern const wchar_t* g_PreSharedKey;
extern const wchar_t* g_TriggerEvent;