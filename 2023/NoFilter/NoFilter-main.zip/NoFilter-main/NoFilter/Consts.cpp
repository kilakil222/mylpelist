#include "Consts.h"

const wchar_t* g_PolicyName = L"RonPolicy";
GUID g_ProviderGuid = FWPM_PROVIDER_IKEEXT;
const wchar_t* g_LocalAddress = L"127.0.0.1";
const wchar_t* g_RemoteAddress = L"127.0.0.1";
const wchar_t* g_PreSharedKey = L"psk";
const wchar_t* g_TriggerEvent = L"TriggerEvent";