# NoFilter
Tool for abusing the Windows Filtering Platform for privilege escalation. It can launch a new console as "NT AUTHORITY\SYSTEM" or as another user that is logged on to the machine.

## Usage

    Usage: NoFilter.exe [-s] [SESSION_ID]

## Credits

* [Ron Ben Yizhak](https://twitter.com/RonB_Y)

## References

* https://www.deepinstinct.com/blog/nofilter-abusing-windows-filtering-platform-for-privilege-escalation
* https://googleprojectzero.blogspot.com/2021/08/understanding-network-access-windows-app.html
* https://scorpiosoftware.net/2022/12/25/introduction-to-the-windows-filtering-platform/
* https://learn.microsoft.com/en-us/windows/win32/fwp/windows-filtering-platform-architecture-overview
* https://learn.microsoft.com/en-us/previous-versions/windows/it-pro/windows-server-2003/cc759130(v=ws.10)
